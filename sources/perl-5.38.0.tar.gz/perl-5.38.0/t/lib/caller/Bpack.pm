# for use by caller.t for GH #15109 and other tests
package Bpack;
use Cpack;
1;

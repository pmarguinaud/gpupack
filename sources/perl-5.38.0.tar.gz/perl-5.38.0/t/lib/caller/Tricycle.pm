require Cycle; # part of a cyclic dependency chain

1;

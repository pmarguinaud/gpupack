require Bicycle; # part of a cyclic dependency chain

1;

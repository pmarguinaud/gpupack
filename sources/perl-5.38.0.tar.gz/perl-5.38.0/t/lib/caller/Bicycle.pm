require Tricycle; # part of a cyclic dependency chain

1;

.. cmake-module:: ../../Modules/CheckSourceRuns.cmake

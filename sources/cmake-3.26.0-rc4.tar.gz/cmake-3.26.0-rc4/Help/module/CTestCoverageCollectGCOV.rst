.. cmake-module:: ../../Modules/CTestCoverageCollectGCOV.cmake
